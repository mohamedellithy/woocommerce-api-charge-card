let product_id = '';
let denomenation_id = '';
let account_id = '';
jQuery('#choice_domentation').change(function() {
    product_id = jQuery(this).attr('product-id');
    denomenation_id = jQuery(this).val();
    account_id = jQuery('.account_id').val() ? jQuery('.account_id').val() : '';
    call_ajax();
});

jQuery('.account_id').blur(function() {
    console.log(jQuery(this).val());
    account_id = jQuery(this).val();
    product_id = jQuery('#choice_domentation').attr('product-id');
    denomenation_id = jQuery('#choice_domentation').val();
    call_ajax();
});

function call_ajax() {
    jQuery.ajax({
        type: 'GET',
        url: mintroute_choice_domenation_price_cart_ajax.ajaxurl,
        data: {
            action: 'domenation_price_cart',
            denomenation_id: denomenation_id,
            product_id: product_id,
            account_id: account_id
        },
        dataType: 'json',
        success: function(result) {
            if (typeof result._mintroute_denomination_ID !== 'undefined') {
                jQuery('.container-domenations .row-prices').show();
                jQuery('.container-domenations h2.show-price').html(result._mintroute_denomination_price);
                console.log(result);
            } else {
                jQuery('.container-domenations .row-prices').hide();
            }
            console.log(result);
        }
    });
}